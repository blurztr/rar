Snapchat SQL.sql

Download:
https://gett.su/file/qj3t0bk9z4dl/view.html
